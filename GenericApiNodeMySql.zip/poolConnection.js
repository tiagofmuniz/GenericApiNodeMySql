// poolConnection.js
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const poolConnection = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: 'dbqt5dfhl4qhr4',

});

export default poolConnection;